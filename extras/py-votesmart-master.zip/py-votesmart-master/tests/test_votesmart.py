from __future__ import print_function
from votesmart import *

def test_sanity():
    assert 1 + 1 == 2
