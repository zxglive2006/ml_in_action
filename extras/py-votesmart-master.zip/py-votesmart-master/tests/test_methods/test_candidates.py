from votesmart.methods.candidates import *

def test_Candidates():
    method = Candidates(api_instance='test')
