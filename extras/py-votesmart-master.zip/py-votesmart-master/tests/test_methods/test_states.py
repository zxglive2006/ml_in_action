from votesmart.methods.states import *

def test_State():
    method = State(api_instance='test')
