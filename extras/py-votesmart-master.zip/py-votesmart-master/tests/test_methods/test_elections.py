from votesmart.methods.elections import *

def test_Election():
    method = Election(api_instance='test')
