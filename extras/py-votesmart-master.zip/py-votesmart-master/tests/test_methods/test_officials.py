import pytest
from votesmart.methods.officials import *

def test_Officials():
    method = Officials(api_instance='test')
