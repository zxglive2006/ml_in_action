import pytest
from votesmart.methods.measure import *

def test_Measure():
    method = Measure(api_instance='test')
