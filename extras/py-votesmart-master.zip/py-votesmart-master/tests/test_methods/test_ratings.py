import pytest
from votesmart.methods.ratings import *

def test_Rating():
    method = Rating(api_instance='test')
