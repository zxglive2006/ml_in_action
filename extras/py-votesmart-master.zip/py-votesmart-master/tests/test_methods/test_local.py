import pytest
from votesmart.methods.local import *

def test_Local():
    method = Local(api_instance='test')
