import pytest
from votesmart.methods.district import *

def test_District():
    method = District(api_instance='test')
