import pytest
from votesmart.methods.npat import *

def test_Npat():
    method = Npat(api_instance='test')
