import pytest
from votesmart.methods.leadership import *

def test_Leadership():
    method = Leadership(api_instance='test')
