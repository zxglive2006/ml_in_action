import pytest
from votesmart.methods.office import *

def test_Office():
    method = Office(api_instance='test')
