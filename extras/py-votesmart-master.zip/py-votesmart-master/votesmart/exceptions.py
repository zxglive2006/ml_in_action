class VotesmartApiError(Exception):
    """Exception for Votesmart API errors """
